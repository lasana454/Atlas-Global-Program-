# AMUN Command — functional starter

A free-first, full-stack MUN committee-management starter built with Flask + SQLite. Includes login, role checks, committee creation, account creation, live-updating committee state, speakers list, timer, motions, voting, attendance, announcements, and document review.

## Run locally

1. Install Python 3.10+.
2. In this folder run: `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open `http://localhost:5000`.

First-run login:
- Username: `admin`
- Password: `ChangeMe-2026!`

**Immediately change this password / set `AMUN_ADMIN_PASSWORD` before using this with real people.** The starter does not expose public signup; Secretariat creates accounts from the dashboard. Set `SESSION_SECRET` to a long random value in deployment secrets.

## Deploying with Replit

1. Create a new Python app in Replit.
2. Upload the files in this project (or import the ZIP).
3. Run `pip install -r requirements.txt` if dependencies aren't installed automatically.
4. Add secrets `SESSION_SECRET` and `AMUN_ADMIN_PASSWORD` in Replit Secrets.
5. Run the app and test with a chair and delegate account.
6. Only publish after testing role access, voting, and data persistence. Check the host's current free-plan limits; free hosting may sleep or have usage limits.

## Important limitations before a real conference

- This is a functional MVP, not a security-audited production system.
- Live state refreshes by polling every 3 seconds rather than WebSockets.
- SQLite is suitable for testing/small pilots; a hosted multi-user deployment may need a managed database and persistent storage.
- A vote is one choice per delegate per motion; chairs/secretariat can open and close voting.
- There is no password-reset email flow, email verification, public registration, file upload, or multi-factor authentication yet.
- Use test data first. Do not store sensitive personal information.
