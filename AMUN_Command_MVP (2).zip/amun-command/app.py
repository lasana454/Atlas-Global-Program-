import os, sqlite3, secrets, json
from datetime import datetime, timezone
from functools import wraps
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, g, request, redirect, url_for, session, flash, jsonify, render_template, abort

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DB_PATH = os.environ.get('AMUN_DB_PATH', os.path.join(BASE_DIR, 'amun_command.db'))
app = Flask(__name__)
app.secret_key = os.environ.get('SESSION_SECRET') or secrets.token_hex(32)

SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 password_hash TEXT NOT NULL, display_name TEXT NOT NULL,
 role TEXT NOT NULL CHECK(role IN ('secretariat','chair','delegate')),
 committee_id INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS committees (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, topic TEXT DEFAULT '',
 chair_id INTEGER, session_status TEXT NOT NULL DEFAULT 'not_started',
 speaker_seconds INTEGER NOT NULL DEFAULT 60, timer_started_at REAL, timer_remaining INTEGER DEFAULT 60,
 timer_running INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS speakers (
 id INTEGER PRIMARY KEY AUTOINCREMENT, committee_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'waiting', position INTEGER NOT NULL DEFAULT 0,
 added_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS motions (
 id INTEGER PRIMARY KEY AUTOINCREMENT, committee_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 motion_type TEXT NOT NULL, details TEXT NOT NULL, duration_minutes INTEGER DEFAULT 0,
 speaking_seconds INTEGER DEFAULT 0, status TEXT NOT NULL DEFAULT 'pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS votes (
 id INTEGER PRIMARY KEY AUTOINCREMENT, motion_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 choice TEXT NOT NULL CHECK(choice IN ('yes','no','abstain')), UNIQUE(motion_id,user_id)
);
CREATE TABLE IF NOT EXISTS attendance (
 id INTEGER PRIMARY KEY AUTOINCREMENT, committee_id INTEGER NOT NULL, user_id INTEGER NOT NULL,
 present INTEGER NOT NULL DEFAULT 1, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(committee_id,user_id)
);
CREATE TABLE IF NOT EXISTS announcements (
 id INTEGER PRIMARY KEY AUTOINCREMENT, committee_id INTEGER, author_id INTEGER NOT NULL,
 title TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS documents (
 id INTEGER PRIMARY KEY AUTOINCREMENT, committee_id INTEGER NOT NULL, author_id INTEGER NOT NULL,
 title TEXT NOT NULL, body TEXT NOT NULL, doc_type TEXT NOT NULL DEFAULT 'working_paper',
 status TEXT NOT NULL DEFAULT 'submitted', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS audit_log (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, committee_id INTEGER,
 action TEXT NOT NULL, detail TEXT DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
'''

def db():
    if 'db' not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute('PRAGMA foreign_keys = ON')
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    conn = g.pop('db', None)
    if conn is not None: conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.executescript(SCHEMA)
    conn.commit()
    # Create one-time setup credentials only if the database has no users.
    if conn.execute('SELECT COUNT(*) FROM users').fetchone()[0] == 0:
        conn.execute('INSERT INTO users(username,password_hash,display_name,role) VALUES(?,?,?,?)',
                     ('admin', generate_password_hash(os.environ.get('AMUN_ADMIN_PASSWORD', 'ChangeMe-2026!')), 'AMUN Secretariat', 'secretariat'))
        conn.commit()
    conn.close()

init_db()

def current_user():
    uid = session.get('user_id')
    if not uid: return None
    return db().execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user(): return redirect(url_for('login'))
        return fn(*args, **kwargs)
    return wrapper

def roles(*allowed):
    def deco(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            u = current_user()
            if not u: return redirect(url_for('login'))
            if u['role'] not in allowed: abort(403)
            return fn(*args, **kwargs)
        return wrapper
    return deco

def log_action(action, detail='', committee_id=None):
    u = current_user()
    db().execute('INSERT INTO audit_log(user_id,committee_id,action,detail) VALUES(?,?,?,?)',
                 (u['id'] if u else None, committee_id, action, detail[:500]))
    db().commit()

def get_committee(cid, user=None):
    c = db().execute('SELECT * FROM committees WHERE id=?', (cid,)).fetchone()
    if not c: abort(404)
    u = user or current_user()
    if u and u['role'] != 'secretariat' and u['committee_id'] != c['id']:
        abort(403)
    return c

@app.context_processor
def inject_globals():
    return {'me': current_user(), 'now_year': datetime.now().year}

@app.route('/')
def index():
    if not current_user(): return redirect(url_for('login'))
    return redirect(url_for('dashboard'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username','').strip().lower()
        password = request.form.get('password','')
        user = db().execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
        if user and check_password_hash(user['password_hash'], password):
            session.clear(); session['user_id'] = user['id']
            return redirect(url_for('dashboard'))
        flash('Login failed. Check your username and password.', 'error')
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
@login_required
def logout():
    session.clear(); return redirect(url_for('login'))

@app.route('/dashboard')
@login_required
def dashboard():
    u = current_user(); conn = db()
    if u['role'] == 'secretariat':
        committees = conn.execute('''SELECT c.*, (SELECT COUNT(*) FROM users u WHERE u.committee_id=c.id) AS members
                                    FROM committees c ORDER BY c.id DESC''').fetchall()
        users = conn.execute('''SELECT u.*, c.name AS committee_name FROM users u LEFT JOIN committees c ON c.id=u.committee_id ORDER BY u.id DESC''').fetchall()
        logs = conn.execute('''SELECT a.*, u.display_name FROM audit_log a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 20''').fetchall()
        return render_template('dashboard.html', committees=committees, users=users, logs=logs)
    c = conn.execute('SELECT * FROM committees WHERE id=?', (u['committee_id'],)).fetchone() if u['committee_id'] else None
    return render_template('dashboard.html', committee=c, committees=[c] if c else [], users=[], logs=[])

@app.route('/committees/create', methods=['POST'])
@roles('secretariat')
def create_committee():
    name = request.form.get('name','').strip(); topic = request.form.get('topic','').strip()
    if not name: flash('Committee name is required.', 'error'); return redirect(url_for('dashboard'))
    cur = db().execute('INSERT INTO committees(name,topic) VALUES(?,?)', (name, topic)); db().commit()
    log_action('committee_created', name, cur.lastrowid)
    flash('Committee created.', 'success'); return redirect(url_for('dashboard'))

@app.route('/users/create', methods=['POST'])
@roles('secretariat')
def create_user():
    username = request.form.get('username','').strip().lower(); display_name = request.form.get('display_name','').strip()
    password = request.form.get('password',''); role = request.form.get('role','delegate')
    committee_raw = request.form.get('committee_id','').strip()
    if role not in ('secretariat','chair','delegate') or not username or not display_name or len(password) < 10:
        flash('Enter all fields. Passwords must be at least 10 characters.', 'error'); return redirect(url_for('dashboard'))
    cid = int(committee_raw) if committee_raw.isdigit() else None
    if role in ('chair','delegate') and (not cid or not db().execute('SELECT id FROM committees WHERE id=?',(cid,)).fetchone()):
        flash('Chairs and delegates must be assigned to a valid committee.', 'error'); return redirect(url_for('dashboard'))
    try:
        db().execute('INSERT INTO users(username,password_hash,display_name,role,committee_id) VALUES(?,?,?,?,?)',
                     (username, generate_password_hash(password), display_name, role, cid)); db().commit()
        log_action('user_created', f'{username} ({role})', cid); flash(f'Account created for {username}.', 'success')
    except sqlite3.IntegrityError: flash('That username is already in use.', 'error')
    return redirect(url_for('dashboard'))

@app.route('/committee/<int:cid>')
@login_required
def committee(cid):
    u=current_user(); c=get_committee(cid,u); conn=db()
    speakers=conn.execute('''SELECT s.*,u.display_name,u.role FROM speakers s JOIN users u ON u.id=s.user_id
                             WHERE s.committee_id=? ORDER BY CASE s.status WHEN 'speaking' THEN 0 WHEN 'waiting' THEN 1 ELSE 2 END, s.position, s.id''',(cid,)).fetchall()
    motions=conn.execute('''SELECT m.*,u.display_name FROM motions m JOIN users u ON u.id=m.user_id WHERE m.committee_id=? ORDER BY m.id DESC''',(cid,)).fetchall()
    announcements=conn.execute('''SELECT a.*,u.display_name FROM announcements a JOIN users u ON u.id=a.author_id WHERE a.committee_id IS NULL OR a.committee_id=? ORDER BY a.id DESC LIMIT 20''',(cid,)).fetchall()
    docs=conn.execute('''SELECT d.*,u.display_name FROM documents d JOIN users u ON u.id=d.author_id WHERE d.committee_id=? ORDER BY d.id DESC''',(cid,)).fetchall()
    members=conn.execute('SELECT id,display_name,role FROM users WHERE committee_id=? ORDER BY display_name',(cid,)).fetchall()
    attendance=conn.execute('''SELECT u.id,u.display_name,COALESCE(a.present,0) AS present FROM users u LEFT JOIN attendance a ON a.user_id=u.id AND a.committee_id=? WHERE u.committee_id=? ORDER BY u.display_name''',(cid,cid)).fetchall()
    return render_template('committee.html', committee=c, speakers=speakers, motions=motions, announcements=announcements, docs=docs, members=members, attendance=attendance)

@app.route('/api/committee/<int:cid>')
@login_required
def committee_state(cid):
    u=current_user(); c=get_committee(cid,u); conn=db()
    speakers=conn.execute('''SELECT s.id,s.status,s.position,u.display_name FROM speakers s JOIN users u ON u.id=s.user_id WHERE s.committee_id=? AND s.status IN ('waiting','speaking') ORDER BY CASE s.status WHEN 'speaking' THEN 0 WHEN 'waiting' THEN 1 ELSE 2 END,s.position,s.id''',(cid,)).fetchall()
    motions=conn.execute('''SELECT m.id,m.motion_type,m.details,m.duration_minutes,m.speaking_seconds,m.status,m.created_at,u.display_name FROM motions m JOIN users u ON u.id=m.user_id WHERE m.committee_id=? ORDER BY m.id DESC LIMIT 25''',(cid,)).fetchall()
    votes={}
    for m in motions:
        if m['status'] in ('voting','passed','failed'):
            rows=conn.execute('SELECT choice,COUNT(*) AS n FROM votes WHERE motion_id=? GROUP BY choice',(m['id'],)).fetchall()
            votes[str(m['id'])]={r['choice']:r['n'] for r in rows}
    rem=c['timer_remaining'] or c['speaker_seconds']
    if c['timer_running'] and c['timer_started_at']:
        rem=max(0, int(rem-(datetime.now(timezone.utc).timestamp()-c['timer_started_at'])))
    return jsonify({'committee':{'id':c['id'],'name':c['name'],'topic':c['topic'],'session_status':c['session_status'],'speaker_seconds':c['speaker_seconds'],'timer_remaining':rem,'timer_running':bool(c['timer_running'])},'speakers':[dict(x) for x in speakers],'motions':[dict(x) for x in motions],'votes':votes,'server_time':datetime.now(timezone.utc).isoformat()})

@app.route('/committee/<int:cid>/speaker/add', methods=['POST'])
@login_required
def speaker_add(cid):
    u=current_user(); c=get_committee(cid,u)
    target=int(request.form.get('user_id') or u['id'])
    target_user=db().execute('SELECT * FROM users WHERE id=? AND committee_id=?',(target,cid)).fetchone()
    if not target_user: abort(400)
    if u['role'] not in ('secretariat','chair') and target != u['id']: abort(403)
    if db().execute("SELECT id FROM speakers WHERE committee_id=? AND user_id=? AND status IN ('waiting','speaking')",(cid,target)).fetchone():
        flash('That delegate is already on the active speakers list.', 'error')
    else:
        pos=db().execute('SELECT COALESCE(MAX(position),0)+1 FROM speakers WHERE committee_id=?',(cid,)).fetchone()[0]
        db().execute('INSERT INTO speakers(committee_id,user_id,position) VALUES(?,?,?)',(cid,target,pos)); db().commit(); log_action('speaker_added',target_user['display_name'],cid)
    return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/speaker/<int:sid>/<action>', methods=['POST'])
@roles('secretariat','chair')
def speaker_action(cid,sid,action):
    get_committee(cid); s=db().execute('SELECT * FROM speakers WHERE id=? AND committee_id=?',(sid,cid)).fetchone()
    if not s: abort(404)
    if action=='next':
        db().execute("UPDATE speakers SET status='finished' WHERE committee_id=? AND status='speaking'",(cid,))
        db().execute("UPDATE speakers SET status='speaking' WHERE id=?",(sid,))
        db().execute('UPDATE committees SET timer_remaining=speaker_seconds,timer_running=0,timer_started_at=NULL WHERE id=?',(cid,))
    elif action=='remove': db().execute("UPDATE speakers SET status='removed' WHERE id=?",(sid,))
    elif action=='reset': db().execute("UPDATE speakers SET status='waiting' WHERE id=?",(sid,))
    else: abort(400)
    db().commit(); log_action('speaker_'+action,str(sid),cid); return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/timer', methods=['POST'])
@roles('secretariat','chair')
def timer_action(cid):
    c=get_committee(cid); action=request.form.get('action'); conn=db()
    rem=c['timer_remaining'] or c['speaker_seconds']
    if c['timer_running'] and c['timer_started_at']:
        rem=max(0,int(rem-(datetime.now(timezone.utc).timestamp()-c['timer_started_at'])))
    if action=='start': conn.execute('UPDATE committees SET timer_remaining=?,timer_started_at=?,timer_running=1 WHERE id=?',(rem,datetime.now(timezone.utc).timestamp(),cid))
    elif action=='pause': conn.execute('UPDATE committees SET timer_remaining=?,timer_started_at=NULL,timer_running=0 WHERE id=?',(rem,cid))
    elif action=='reset': conn.execute('UPDATE committees SET timer_remaining=speaker_seconds,timer_started_at=NULL,timer_running=0 WHERE id=?',(cid,))
    elif action=='set':
        try: secs=max(1,min(3600,int(request.form.get('seconds','60'))))
        except ValueError: secs=60
        conn.execute('UPDATE committees SET speaker_seconds=?,timer_remaining=?,timer_started_at=NULL,timer_running=0 WHERE id=?',(secs,secs,cid))
    else: abort(400)
    conn.commit(); log_action('timer_'+action,'',cid); return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/session', methods=['POST'])
@roles('secretariat','chair')
def session_action(cid):
    get_committee(cid); status=request.form.get('status')
    if status not in ('not_started','in_session','suspended','adjourned'): abort(400)
    db().execute('UPDATE committees SET session_status=? WHERE id=?',(status,cid)); db().commit(); log_action('session_status',status,cid)
    return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/motion', methods=['POST'])
@login_required
def create_motion(cid):
    u=current_user(); get_committee(cid,u)
    typ=request.form.get('motion_type','other'); details=request.form.get('details','').strip()
    if typ not in ('moderated_caucus','unmoderated_caucus','break','close_debate','other') or not details:
        flash('Please provide a motion and its details.', 'error'); return redirect(url_for('committee',cid=cid))
    try: duration=max(0,min(120,int(request.form.get('duration_minutes','0')))); speaking=max(0,min(600,int(request.form.get('speaking_seconds','0'))))
    except ValueError: duration=speaking=0
    cur=db().execute('INSERT INTO motions(committee_id,user_id,motion_type,details,duration_minutes,speaking_seconds) VALUES(?,?,?,?,?,?)',(cid,u['id'],typ,details,duration,speaking)); db().commit()
    log_action('motion_submitted',details,cid); return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/motion/<int:mid>/<action>', methods=['POST'])
@roles('secretariat','chair')
def motion_action(cid,mid,action):
    get_committee(cid); m=db().execute('SELECT * FROM motions WHERE id=? AND committee_id=?',(mid,cid)).fetchone()
    if not m: abort(404)
    statuses={'open':'pending','vote':'voting','pass':'passed','fail':'failed','withdraw':'withdrawn'}
    if action not in statuses: abort(400)
    db().execute('UPDATE motions SET status=? WHERE id=?',(statuses[action],mid)); db().commit(); log_action('motion_'+action,m['details'],cid)
    return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/motion/<int:mid>/cast-vote', methods=['POST'])
@login_required
def cast_vote(cid,mid):
    u=current_user(); get_committee(cid,u); m=db().execute('SELECT * FROM motions WHERE id=? AND committee_id=?',(mid,cid)).fetchone()
    if not m or m['status']!='voting': flash('Voting is not open for that motion.', 'error'); return redirect(url_for('committee',cid=cid))
    if u['role']!='delegate': flash('Only delegates can cast a vote in this workspace.', 'error'); return redirect(url_for('committee',cid=cid))
    choice=request.form.get('choice')
    if choice not in ('yes','no','abstain'): abort(400)
    db().execute('INSERT INTO votes(motion_id,user_id,choice) VALUES(?,?,?) ON CONFLICT(motion_id,user_id) DO UPDATE SET choice=excluded.choice',(mid,u['id'],choice)); db().commit(); log_action('vote_cast',f'motion {mid}: {choice}',cid)
    flash('Your vote has been recorded.', 'success'); return redirect(url_for('committee',cid=cid))

@app.route('/committee/<int:cid>/attendance', methods=['POST'])
@roles('secretariat','chair')
def set_attendance(cid):
    get_committee(cid); uid=int(request.form.get('user_id')); present=1 if request.form.get('present')=='1' else 0
    if not db().execute('SELECT id FROM users WHERE id=? AND committee_id=?',(uid,cid)).fetchone(): abort(400)
    db().execute('INSERT INTO attendance(committee_id,user_id,present) VALUES(?,?,?) ON CONFLICT(committee_id,user_id) DO UPDATE SET present=excluded.present,updated_at=CURRENT_TIMESTAMP',(cid,uid,present)); db().commit()
    log_action('attendance_updated',f'user={uid}, present={present}',cid); return redirect(url_for('committee',cid=cid))

@app.route('/announcements/create', methods=['POST'])
@roles('secretariat','chair')
def create_announcement():
    u=current_user(); title=request.form.get('title','').strip(); body=request.form.get('body','').strip(); raw=request.form.get('committee_id','all')
    cid=int(raw) if raw.isdigit() else None
    if not title or not body: flash('Announcement title and message are required.', 'error'); return redirect(url_for('dashboard'))
    if u['role']=='chair' and cid != u['committee_id']: abort(403)
    db().execute('INSERT INTO announcements(committee_id,author_id,title,body) VALUES(?,?,?,?)',(cid,u['id'],title,body)); db().commit(); log_action('announcement_created',title,cid)
    flash('Announcement published.', 'success'); return redirect(url_for('committee',cid=cid) if cid else url_for('dashboard'))

@app.route('/committee/<int:cid>/documents/create', methods=['POST'])
@login_required
def create_document(cid):
    u=current_user(); get_committee(cid,u); title=request.form.get('title','').strip(); body=request.form.get('body','').strip(); typ=request.form.get('doc_type','working_paper')
    if typ not in ('working_paper','draft_resolution','amendment','other'): abort(400)
    if not title or not body: flash('Document title and content are required.', 'error'); return redirect(url_for('committee',cid=cid))
    db().execute('INSERT INTO documents(committee_id,author_id,title,body,doc_type) VALUES(?,?,?,?,?)',(cid,u['id'],title,body,typ)); db().commit(); log_action('document_submitted',title,cid)
    flash('Document submitted.', 'success'); return redirect(url_for('committee',cid=cid))

@app.route('/documents/<int:did>/status', methods=['POST'])
@roles('secretariat','chair')
def document_status(did):
    d=db().execute('SELECT * FROM documents WHERE id=?',(did,)).fetchone()
    if not d: abort(404)
    get_committee(d['committee_id']); status=request.form.get('status')
    if status not in ('submitted','under_review','accepted','needs_revision','rejected'): abort(400)
    db().execute('UPDATE documents SET status=? WHERE id=?',(status,did)); db().commit(); log_action('document_status',f'{did}: {status}',d['committee_id'])
    return redirect(url_for('committee',cid=d['committee_id']))

@app.route('/health')
def health(): return jsonify({'ok':True,'app':'AMUN Command'})

@app.errorhandler(403)
def forbidden(_e): return render_template('error.html', code=403, message='You do not have permission to access this page.'),403
@app.errorhandler(404)
def not_found(_e): return render_template('error.html', code=404, message='The page or item could not be found.'),404

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
