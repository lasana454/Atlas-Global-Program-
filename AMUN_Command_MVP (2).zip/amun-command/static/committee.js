(() => {
 const api = window.AMUN_API_URL;
 if (!api) return;
 const cid = window.AMUN_COMMITTEE_ID;
 const role = window.AMUN_ROLE;
 const isChair = role === 'chair' || role === 'secretariat';
 const isDelegate = role === 'delegate';
 const $ = (id) => document.getElementById(id);
 const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const fmt = (s) => { s=Math.max(0, Number(s)||0); return `${String(Math.floor(s/60)).padStart(2,'0')}:${String(s%60).padStart(2,'0')}`; };
 const statusClass = (s) => String(s||'').toLowerCase().replace(/[^a-z_]/g,'');
 const formButton = (url, action, label, cls='button small') => `<form method="post" action="${url}"><button class="${cls}" type="submit" ${action ? `name="action" value="${action}"` : ''}>${label}</button></form>`;
 let lastMotionSignature = '';
 function renderMotions(d) {
   const ml=$('motion-live-list'); if(!ml) return;
   const signature=JSON.stringify([d.motions,d.votes]);
   if(signature===lastMotionSignature) return;
   lastMotionSignature=signature;
   if(!d.motions.length){ml.innerHTML='<div class="empty compact">No motions submitted yet.</div>';return;}
   ml.innerHTML=d.motions.map(m=>{
     const tally=d.votes[String(m.id)]||{};
     const tallyText=Object.entries(tally).map(([k,v])=>`${({yes:'Yes',no:'No',abstain:'Abstain'})[k]||k}: ${v}`).join(' · ');
     let vote='';
     if(isDelegate && m.status==='voting') vote=`<form method="post" action="/committee/${cid}/motion/${m.id}/cast-vote" class="vote-buttons"><button class="button primary small" name="choice" value="yes">Yes</button><button class="button secondary small" name="choice" value="no">No</button><button class="button ghost small" name="choice" value="abstain">Abstain</button></form>`;
     let controls='';
     if(isChair){
       controls='<div class="button-row wrap">';
       if(m.status!=='voting') controls+=formButton(`/committee/${cid}/motion/${m.id}/vote`,'','Open vote','button primary small');
       controls+=formButton(`/committee/${cid}/motion/${m.id}/pass`,'','Mark passed','button secondary small');
       controls+=formButton(`/committee/${cid}/motion/${m.id}/fail`,'','Mark failed','button ghost small');
       controls+='</div>';
     }
     return `<article class="motion-item"><div class="motion-head"><span class="motion-type">${esc(m.motion_type.replaceAll('_',' '))}</span><span class="mini-status ${statusClass(m.status)}">${esc(m.status)}</span></div><p>${esc(m.details)}</p><small>Submitted by ${esc(m.display_name)} · ${esc(m.created_at)}</small>${vote}${controls}<div class="vote-tally">${tallyText ? `Live tally · ${esc(tallyText)}` : ''}</div></article>`;
   }).join('');
 }
 async function refresh(){
  try {
   const r=await fetch(api,{credentials:'same-origin',cache:'no-store'}); if(!r.ok) return;
   const d=await r.json(); const c=d.committee;
   const display=$('timer-display'); if(display) display.textContent=fmt(c.timer_remaining);
   const state=$('timer-state'); if(state) state.textContent=c.timer_running?'RUNNING':'PAUSED';
   const progress=$('timer-progress'); if(progress) progress.style.width=`${Math.max(0,Math.min(100,c.timer_remaining/(c.speaker_seconds||60)*100))}%`;
   const sc=$('speaker-count'); if(sc) sc.textContent=`${d.speakers.filter(s=>s.status==='waiting').length} waiting`;
   const sl=$('speaker-live-list'); if(sl){
    if(!d.speakers.length) sl.innerHTML='<div class="empty compact">No speakers on the active list.</div>';
    else sl.innerHTML=d.speakers.map((s,i)=>`<div class="speaker-row ${s.status==='speaking'?'speaking':''}"><span class="speaker-number">${i+1}</span><div class="speaker-info"><strong>${esc(s.display_name)}</strong><small>${s.status==='speaking'?'CURRENT SPEAKER':'IN QUEUE'}</small></div>${isChair && s.status==='waiting' ? formButton(`/committee/${cid}/speaker/${s.id}/next`,'','Recognize','button primary small') : ''}</div>`).join('');
   }
   renderMotions(d);
   const sync=$('last-sync'); if(sync) sync.textContent=`Synced ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
  } catch(_e) { const sync=$('last-sync'); if(sync) sync.textContent='Reconnecting…'; }
 }
 refresh(); setInterval(refresh,3000);
})();
